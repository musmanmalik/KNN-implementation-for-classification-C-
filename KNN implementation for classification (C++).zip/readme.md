# Notes:
This is an Serial project that is used for KNN classification.
### runing the project
g++ serial_KNN.cpp -o serial_KNN
./serial_KNN 
```
 * this command accepts a file name which can be changed from the top of the file *
```
## Tech
- C++
- GCC